﻿
//alert("Before ActiveX Object");

//fso = new ActiveXObject("Scripting.FileSystemObject");
//objUserInfo = new ActiveXObject("WScript.Network");

// = objUserInfo.UserName;

//vUsername=Request.vUsernameServerVariables.Get("AUTH_USER");

//alert(vUsername);
//do {
    var person = prompt("Please enter your username", null);

     if (person != null) {
         vUsername = person;
     }
//}
//while (person != null)

//alert(vUsername);


//claim_no = 1;
//var today = new Date();
//var dd = String(today.getDate());
//if (dd < 10)
//    dd = String('0' + dd);

//var mm = today.getMonth() + 1; //January is 0!
//var yyyy = String(today.getFullYear());
//var full_date = dd + mm + yyyy;

////Defining the path name for the Text file created
//shell = new ActiveXObject("WScript.Shell");

////pathToMyDocuments = shell.SpecialFolders('MyDocuments');
//pathToMyDocuments = fso.GetSpecialFolder(2);
//FileName = vUsername + '_' + full_date + '_' + "Claimfile" + '_' + claim_no + '.txt';
//FilePath = pathToMyDocuments + '\\' + FileName;

//Splitting and getting code in the DDC code box
function GetCodeDDC() {
    var e = document.getElementById("DDC").value;
    if (e == "") {
        document.getElementById("DDCcode").value = "";
    }
    else {
        var splitCode = e.split('-');
        if (!splitCode[splitCode.length - 1] == "")
            document.getElementById("DDCcode").value = splitCode[splitCode.length - 1];
    }
}

//splitting and getting code in the DOC CODE BOX
function GetCodeDOC() {
    var e = document.getElementById("DOC").value;
    if (e == "") {
        document.getElementById("DOCcode").value = "";
    }
    else {
        var splitCode = e.split('-');
        if (!splitCode[splitCode.length - 1] == "")
            document.getElementById("DOCcode").value = splitCode[splitCode.length - 1];

    }
}

function fnFieldValidation() {

    var xhttp = new XMLHttpRequest();
    xhttp.open("GET", "EB_Config.xml", false);
    xhttp.send();
    var Error = 0;
    var xmlDoc = xhttp.responseXML;
    if (!xmlDoc)
        xmlDoc = (new DOMParser).parseFromString(xhttp.responseText, 'text/html');

    //Validating for the EDM
    document.getElementById("imgedm").style.visibility = "hidden";
    var edmval = document.getElementById("edm").value;

    if (edmval == "") {
    }
    else if (!Number(edmval)) {
        document.getElementById("imgedm").style.visibility = "visible";
        document.getElementById("spedm").textContent = "Please Enter numeric value";
        Error = 1;
    }

    //Validating The Policy Number
    var x = xmlDoc.getElementsByTagName("Field")[0];
    y = x.getAttributeNode("Name");
    txt = y.nodeValue;
    document.getElementById("imgpcn").style.visibility = "hidden";
    if (txt == "PHNO") {
        var polno1 = document.getElementById("pn").value;
        var pollen = polno1.length;

        //Validating for Blank Condition

        var x1 = xmlDoc.getElementsByTagName("Validate")[0];
        var y1 = x1.getAttributeNode("ValCondValue");
        var polno2 = y.nodeValue;

        //Validating the Length Condition
        var k = xmlDoc.getElementsByTagName("Validate")[2];
        var l = k.getAttributeNode("ValCondValue");
        var polno4 = l.nodeValue;


        if (pollen == polno2) {
            var a = xmlDoc.getElementsByTagName("Validate")[0];
            var b = a.getAttributeNode("ValCondMessage");
            var c = b.nodeValue;
            document.getElementById("imgpcn").style.visibility = "visible";
            document.getElementById("sppcn").textContent = c;
            Error = 1;
        }
        else if (!Number(polno1)) {
            var a = xmlDoc.getElementsByTagName("Validate")[1];
            var b = a.getAttributeNode("ValCondMessage");
            var c = b.nodeValue;
            document.getElementById("imgpcn").style.visibility = "visible";
            document.getElementById("sppcn").textContent = c;
            Error = 1;

        }
        else if (pollen != polno4) {
            var a = xmlDoc.getElementsByTagName("Validate")[2];
            var b = a.getAttributeNode("ValCondMessage");
            var c = b.nodeValue;
            document.getElementById("imgpcn").style.visibility = "visible";
            document.getElementById("sppcn").textContent = c;
            Error = 1;
        }
    }



    //Validating The Certification Number
    var x = xmlDoc.getElementsByTagName("Field")[1];
    y = x.getAttributeNode("Name");
    txt = y.nodeValue;
    document.getElementById("imgcn").style.visibility = "hidden";
    if (txt == "CERTNO") {
        var polno1 = document.getElementById("cn").value;
        var pollen = polno1.length;

        //Validating for Blank Condition

        var x = xmlDoc.getElementsByTagName("Field")[1];
        var x1 = x.getElementsByTagName("Validate")[0];
        var y1 = x1.getAttributeNode("ValCondValue");
        var polno2 = y1.nodeValue;

        //Validating the Length Condition
        var x = xmlDoc.getElementsByTagName("Field")[1];
        var k = x.getElementsByTagName("Validate")[2];
        var l = k.getAttributeNode("ValCondValue");
        var polno4 = l.nodeValue;


        if (pollen == polno2) {
            var x = xmlDoc.getElementsByTagName("Field")[1];
            var a = x.getElementsByTagName("Validate")[0];
            var b = a.getAttributeNode("ValCondMessage");
            var c = b.nodeValue;
            document.getElementById("imgcn").style.visibility = "visible";
            document.getElementById("spcn").textContent = c;
            Error = 1;
        }
        else if (polno1 == /[0-9a-zA-Z]/) {
            var x = xmlDoc.getElementsByTagName("Field")[1];
            var a = x.getElementsByTagName("Validate")[1];
            var b = a.getAttributeNode("ValCondMessage");
            var c = b.nodeValue;
            document.getElementById("imgcn").style.visibility = "visible";
            document.getElementById("spcn").textContent = c;
            Error = 1;
        }
        else if (pollen > polno4) {
            var x = xmlDoc.getElementsByTagName("Field")[1];
            var a = x.getElementsByTagName("Validate")[2];
            var b = a.getAttributeNode("ValCondMessage");
            var c = b.nodeValue;
            document.getElementById("imgcn").style.visibility = "visible";
            document.getElementById("spcn").textContent = c;
            Error = 1;
        }
    }




    //Validating The dependent Number

    var xd = xmlDoc.getElementsByTagName("Field")[4];
    yd = xd.getAttributeNode("Name");
    txtdep = yd.nodeValue;
    document.getElementById("imgdn").style.visibility = "hidden";

    if (txtdep == "DEPNO") {

        var depno1 = document.getElementById("dn").value;
        var deplen = depno1.length;


        //Validating for Blank Condition
        var x1 = xd.getElementsByTagName("Validate")[0];
        var y1 = x1.getAttributeNode("ValCondValue");
        var depval0 = y1.nodeValue;

        //Validating the Length Condition
        var k = xd.getElementsByTagName("Validate")[2];
        var l = k.getAttributeNode("ValCondValue");
        var depval = l.nodeValue;

        if (deplen == depval0) {

            var a = xd.getElementsByTagName("Validate")[0];                          // if blank
            var b = a.getAttributeNode("ValCondMessage");
            var c = b.nodeValue;
            document.getElementById("imgdn").style.visibility = "visible";
            document.getElementById("spdn").textContent = c;
            Error = 1;
        }
        else if (!Number(depno1)) {
            // if not numeric
            var a = xd.getElementsByTagName("Validate")[1];
            var b = a.getAttributeNode("ValCondMessage");
            var c = b.nodeValue;
            document.getElementById("imgdn").style.visibility = "visible";
            document.getElementById("spdn").textContent = c;
            Error = 1;
        }
        else if (deplen != depval) {
            //  if lenght not matching
            var a = xd.getElementsByTagName("Validate")[2];
            var b = a.getAttributeNode("ValCondMessage");
            var c = b.nodeValue;
            document.getElementById("imgdn").style.visibility = "visible";
            document.getElementById("spdn").textContent = c;
            Error = 1;
        }
    }



    //Validating The membership Number
    var xm = xmlDoc.getElementsByTagName("Field")[3];
    ym = xm.getAttributeNode("Name");
    txtmem = ym.nodeValue;
    document.getElementById("imgmn").style.visibility = "hidden";
    if (txtmem == "MNO") {
        var memno1 = document.getElementById("mn").value;
        var memlen = memno1.length;

        //Validating the Length Condition
        var k = xm.getElementsByTagName("Validate")[0];
        var l = k.getAttributeNode("ValCondValue");
        var memval = l.nodeValue;

        if (isNaN(memno1) || memno1 == "") {

        }
        else {
            document.getElementById("imgdn").style.visibility = "hidden";
            document.getElementById("imgcn").style.visibility = "hidden";
            document.getElementById("imgpcn").style.visibility = "hidden";
            if (!Number(memno1)) {                        // if not numeric
                var a = xm.getElementsByTagName("Validate")[1];
                var b = a.getAttributeNode("ValCondMessage");
                var c = b.nodeValue;
                document.getElementById("imgmn").style.visibility = "visible";
                document.getElementById("spmn").textContent = c;
                Error = 1;
            }
            else if (memlen != memval) {           //  if lenght not matching
                var a = xm.getElementsByTagName("Validate")[0];
                var b = a.getAttributeNode("ValCondMessage");
                var c = b.nodeValue;
                document.getElementById("imgmn").style.visibility = "visible";
                document.getElementById("spmn").textContent = c;
                Error = 1;
            }
        }
    }

    //Validating The Patient Name
    var xv = xmlDoc.getElementsByTagName("Field")[2];
    yv = xv.getAttributeNode("Name");
    txtv = yv.nodeValue;
    document.getElementById("imgpn").style.visibility = "hidden";
    var letters = /^[a-zA-Z\s]*$/;

    if (txtv == "PNAME") {
        var valno1 = document.getElementById("pna").value;
        var vallen = valno1.length;


        // Validating for Blank Condition
        var x1 = xv.getElementsByTagName("Validate")[0];
        var y1 = x1.getAttributeNode("ValCondValue");
        var valval0 = y1.nodeValue;

        if (vallen == valval0) {
            var a = xv.getElementsByTagName("Validate")[0];                          // if blank
            var b = a.getAttributeNode("ValCondMessage");
            var c = b.nodeValue;
            document.getElementById("imgpn").style.visibility = "visible";
            document.getElementById("sppn").textContent = c;
            Error = 1;
        }
        else if (!valno1.match(letters)) {                   // if not numeric
            var a = xv.getElementsByTagName("Validate")[1];
            var b = a.getAttributeNode("ValCondMessage");
            var c = b.nodeValue;
            document.getElementById("imgpn").style.visibility = "visible";
            document.getElementById("sppn").textContent = c;
            Error = 1;

        }
    }

    //VALIDATING FOR DATES OF CONSULTANT
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1; //January is 0!
    var yyyy = today.getFullYear();

    document.getElementById("imgdatec").style.visibility = "hidden";

    var doc1 = document.getElementById("DateDOC").value;
    var xdoc = xmlDoc.getElementsByTagName("Field")[5];
    var y = doc1[0] + doc1[1] + doc1[2] + doc1[3];
    var m = doc1[4] + doc1[5];
    var d = doc1[6] + doc1[7];

    if (doc1 == "") {

        var a = xdoc.getElementsByTagName("Validate")[0];
        var b = a.getAttributeNode("ValCondMessage");
        var c = b.nodeValue;
        document.getElementById("imgdatec").style.visibility = "visible";
        document.getElementById("spdatec").textContent = c;
        Error = 1;
    }
    else if (yyyy == y) {
        if (mm == m) {
            if (d > dd) {  //error

                var a = xdoc.getElementsByTagName("Validate")[3];
                var b = a.getAttributeNode("ValCondMessage");
                var c = b.nodeValue;
                document.getElementById("imgdatec").style.visibility = "visible";
                document.getElementById("spdatec").textContent = c;
                Error = 1;
            }
        }
        else if (mm < m) {  //error

            var a = xdoc.getElementsByTagName("Validate")[3];
            var b = a.getAttributeNode("ValCondMessage");
            var c = b.nodeValue;
            document.getElementById("imgdatec").style.visibility = "visible";
            document.getElementById("spdatec").textContent = c;
            Error = 1;
        }
    }
    else if (yyyy < y) {  //error

        var a = xdoc.getElementsByTagName("Validate")[3];
        var b = a.getAttributeNode("ValCondMessage");
        var c = b.nodeValue;
        document.getElementById("imgdatec").style.visibility = "visible";
        document.getElementById("spdatec").textContent = c;
        Error = 1;
    }
    // VALIDATING THE DATE OF RECEIVED
    var dor1 = document.getElementById("DateDOR").value;
    var xdor = xmlDoc.getElementsByTagName("Field")[6];
    var y2 = dor1[0] + dor1[1] + dor1[2] + dor1[3];
    var m2 = dor1[4] + dor1[5];
    var d2 = dor1[6] + dor1[7];
    document.getElementById("imgdater").style.visibility = "hidden";
    if (dor1 == "") {

        var a = xdor.getElementsByTagName("Validate")[0];
        var b = a.getAttributeNode("ValCondMessage");
        var c = b.nodeValue;
        document.getElementById("imgdater").style.visibility = "visible";
        document.getElementById("spdater").textContent = c;
        Error = 1;
    }
    else if (doc1 > dor1) {
        var a = xdor.getElementsByTagName("Validate")[3];
        var b = a.getAttributeNode("ValCondMessage");
        var c = b.nodeValue;
        document.getElementById("imgdater").style.visibility = "visible";
        document.getElementById("spdater").textContent = c;
        Error = 1;
    }
    else if (yyyy == y2) {
        if (mm == m2) {
            if (d2 > dd) {  //error

                var a = xdor.getElementsByTagName("Validate")[3];
                var b = a.getAttributeNode("ValCondMessage");
                var c = b.nodeValue;
                document.getElementById("imgdater").style.visibility = "visible";
                document.getElementById("spdater").textContent = c;
                Error = 1;
            }
        }
        else if (mm < m2) {  //error

            var a = xdor.getElementsByTagName("Validate")[3];
            var b = a.getAttributeNode("ValCondMessage");
            var c = b.nodeValue;
            document.getElementById("imgdater").style.visibility = "visible";
            document.getElementById("spdater").textContent = c;
            Error = 1;
        }
    }
    else if (yyyy < y2) {  //error

        var a = xdor.getElementsByTagName("Validate")[3];
        var b = a.getAttributeNode("ValCondMessage");
        var c = b.nodeValue;
        document.getElementById("imgdater").style.visibility = "visible";
        document.getElementById("spdater").textContent = c;
        Error = 1;
    }

    //Validation for the Amount 1
    var xa1 = xmlDoc.getElementsByTagName("Field")[7];
    ya1 = xa1.getAttributeNode("Name");
    txta1 = ya1.nodeValue;
    document.getElementById("imga1").style.visibility = "hidden";
    if (txta1 == "Amount1") {
        var amt1 = parseFloat(document.getElementById("a1").value);
        var amt1len = amt1.length;

        //Validating for Blank Condition
        var x1 = xa1.getElementsByTagName("Validate")[0];
        var y1 = x1.getAttributeNode("ValCondValue");
        var amtval0 = y1.nodeValue;

        //Validating the Amount Condition
        var k = xa1.getElementsByTagName("Validate")[2];
        var l = k.getAttributeNode("ValCondValue");
        var amt1val = parseFloat(l.nodeValue);

        var num = /[1-4]/g;

        if (amt1 == amtval0) {
            var a = xa1.getElementsByTagName("Validate")[0];
            var b = a.getAttributeNode("ValCondMessage");
            var c = b.nodeValue;
            document.getElementById("imga1").style.visibility = "visible";
            document.getElementById("spa1").textContent = c;
            Error = 1;
        }
        else if (!Number(amt1)) {
            var a = xa1.getElementsByTagName("Validate")[1];
            var b = a.getAttributeNode("ValCondMessage");
            var c = b.nodeValue;
            document.getElementById("imga1").style.visibility = "visible";
            document.getElementById("spa1").textContent = c;
            Error = 1;
        }
        else if (amt1 > amt1val) {
            var a = xa1.getElementsByTagName("Validate")[2];
            var b = a.getAttributeNode("ValCondMessage");
            var c = b.nodeValue;
            document.getElementById("imga1").style.visibility = "visible";
            document.getElementById("spa1").textContent = c;
            Error = 1;
        }
    }

    //Validation for the Amount 2
    var xa2 = xmlDoc.getElementsByTagName("Field")[8];
    ya2 = xa2.getAttributeNode("Name");
    txta2 = ya2.nodeValue;
    document.getElementById("imga2").style.visibility = "hidden";
    if (txta2 == "Amount2") {
        var amt2 = parseFloat(document.getElementById("a2").value);
        var amt2len = amt2.length;

        //Validating the Amount Condition
        var k = xa2.getElementsByTagName("Validate")[2];
        var l = k.getAttributeNode("ValCondValue");
        var amt2val = parseFloat(l.nodeValue);

        if (isNaN(amt2)) {

        }
        else if (!Number(amt2)) {
            var a = xa2.getElementsByTagName("Validate")[1];
            var b = a.getAttributeNode("ValCondMessage");
            var c = b.nodeValue;
            document.getElementById("imga2").style.visibility = "visible";
            document.getElementById("spa2").textContent = c;
            Error = 1;
        }
        else if (amt2 > amt2val) {
            var a = xa2.getElementsByTagName("Validate")[2];
            var b = a.getAttributeNode("ValCondMessage");
            var c = b.nodeValue;
            document.getElementById("imga2").style.visibility = "visible";
            document.getElementById("spa2").textContent = c;
            Error = 1;
        }
    }

    //Validation for the Amount 3
    var xa3 = xmlDoc.getElementsByTagName("Field")[9];
    ya3 = xa3.getAttributeNode("Name");
    txta3 = ya3.nodeValue;
    document.getElementById("imga3").style.visibility = "hidden";
    if (txta3 == "Amount3") {
        var amt3 = parseFloat(document.getElementById("a3").value);
        var amt3len = amt3.length;

        //Validating the Amount Condition
        var k = xa3.getElementsByTagName("Validate")[2];
        var l = k.getAttributeNode("ValCondValue");
        var amt3val = parseFloat(l.nodeValue);

        if (isNaN(amt3)) {
        }
        else if (!Number(amt3)) {
            var a = xa3.getElementsByTagName("Validate")[1];
            var b = a.getAttributeNode("ValCondMessage");
            var c = b.nodeValue;
            document.getElementById("imga3").style.visibility = "visible";
            document.getElementById("spa3").textContent = c;
            Error = 1;
        }
        if (amt3 > amt3val) {
            var a = xa3.getElementsByTagName("Validate")[2];
            var b = a.getAttributeNode("ValCondMessage");
            var c = b.nodeValue;
            document.getElementById("imga3").style.visibility = "visible";
            document.getElementById("spa3").textContent = c;
            Error = 1;
        }
    }

    //Validation for the Amount 4
    var xa4 = xmlDoc.getElementsByTagName("Field")[10];
    ya4 = xa4.getAttributeNode("Name");
    txta4 = ya4.nodeValue;
    document.getElementById("imga4").style.visibility = "hidden";
    if (txta4 == "Amount4") {
        var amt4 = parseFloat(document.getElementById("a4").value);
        var amt4len = amt4.length;

        //Validating the Amount Condition
        var k = xa4.getElementsByTagName("Validate")[2];
        var l = k.getAttributeNode("ValCondValue");
        var amt4val = parseFloat(l.nodeValue);


        if (isNaN(amt5)) {
        }
        else if (!Number(amt4)) {
            var a = xa4.getElementsByTagName("Validate")[1];
            var b = a.getAttributeNode("ValCondMessage");
            var c = b.nodeValue;
            document.getElementById("imga4").style.visibility = "visible";
            document.getElementById("spa4").textContent = c;
            Error = 1;
        }
        if (amt4 > amt4val) {
            var a = xa4.getElementsByTagName("Validate")[2];
            var b = a.getAttributeNode("ValCondMessage");
            var c = b.nodeValue;
            document.getElementById("imga4").style.visibility = "visible";
            document.getElementById("spa4").textContent = c;
            Error = 1;

        }
    }

    //Validation for the Amount 5
    var xa5 = xmlDoc.getElementsByTagName("Field")[11];
    ya5 = xa5.getAttributeNode("Name");
    txta5 = ya5.nodeValue;
    document.getElementById("imga5").style.visibility = "hidden";
    if (txta5 == "Amount5") {
        var amt5 = parseFloat(document.getElementById("a5").value);
        var amt5len = amt5.length;
        //Validating the Amount Condition
        var k = xa5.getElementsByTagName("Validate")[2];
        var l = k.getAttributeNode("ValCondValue");
        var amt5val = parseFloat(l.nodeValue);

        if (isNaN(amt5)) {
        }
        else if (!Number(amt5)) {
            var a = xa5.getElementsByTagName("Validate")[1];
            var b = a.getAttributeNode("ValCondMessage");
            var c = b.nodeValue;
            document.getElementById("imga5").style.visibility = "visible";
            document.getElementById("spa5").textContent = c;
            Error = 1;
        }
        else if (amt5 > amt5val) {
            var a = xa5.getElementsByTagName("Validate")[2];
            var b = a.getAttributeNode("ValCondMessage");
            var c = b.nodeValue;
            document.getElementById("imga5").style.visibility = "visible";
            document.getElementById("spa5").textContent = c;
            Error = 1;
        }
    }

    // validate diag
    document.getElementById("imgddc").style.visibility = "hidden";
    var xddc = xmlDoc.getElementsByTagName("Field")[12];
    var yddc = xddc.getAttributeNode("Name");
    var txtdiag = yddc.nodeValue;
    if (txtdiag == "DIAG") {
        var digno1 = document.getElementById("DDC").value;;
        var diglen = digno1.length;
        var x1 = xmlDoc.getElementsByTagName("Validate")[0];
        var y1 = x1.getAttributeNode("ValCondValue");
        var digno2 = y1.nodeValue;
        if (digno1 == digno2) {
            var a = xddc.getElementsByTagName("Validate")[0];
            var b = a.getAttributeNode("ValCondMessage");
            var c = b.nodeValue;
            document.getElementById("imgddc").style.visibility = "visible";
            document.getElementById("spddc").textContent = c;
            Error = 1;
        }
    }

    // validate DR
    document.getElementById("imgdc").style.visibility = "hidden";
    var xdoc = xmlDoc.getElementsByTagName("Field")[14];
    var ydoc = xdoc.getAttributeNode("Name");
    var txtdoc = ydoc.nodeValue;
    if (txtdoc == "DR") {
        var drno1 = document.getElementById("DOC").value;
        var drlen = drno1.length;

        var xd = xmlDoc.getElementsByTagName("Validate")[0];
        var yd = xd.getAttributeNode("ValCondValue");
        var drno2 = yd.nodeValue;
        if (drlen == drno2) {
            var ad = xdoc.getElementsByTagName("Validate")[0];
            var bd = ad.getAttributeNode("ValCondMessage");
            var cd = bd.nodeValue;
            document.getElementById("imgdc").style.visibility = "visible";
            document.getElementById("spdoc").textContent = cd;
            Error = 1;
        }
    }



    if (Error == 0) {

        var p = document.getElementById("pn").value;
        var IDdata = [];
        var skillsSelect = document.getElementById("ct");
        IDdata[0] = skillsSelect.options[skillsSelect.selectedIndex].text;
        IDdata[1] = document.getElementById('pn').value;
        IDdata[2] = document.getElementById('cn').value;
        IDdata[3] = document.getElementById('dn').value;
        IDdata[4] = document.getElementById('mn').value;
        IDdata[5] = document.getElementById('pna').value;
        IDdata[6] = document.getElementById('DateDOC').value;
        IDdata[7] = document.getElementById('DateDOR').value;
        IDdata[8] = document.getElementById('edm').value;
        IDdata[9] = document.getElementById('DDCcode').value;
        IDdata[10] = document.getElementById('r4').value;
        IDdata[11] = document.getElementById('DOCcode').value;
        IDdata[12] = document.getElementById('Con1').value;
        IDdata[13] = document.getElementById('Con2').value;
        IDdata[14] = document.getElementById('Con3').value;
        IDdata[15] = document.getElementById('Con4').value;
        IDdata[16] = document.getElementById('Con5').value;
        IDdata[17] = document.getElementById('a1').value;
        IDdata[18] = document.getElementById('a2').value;
        IDdata[19] = document.getElementById('a3').value;
        IDdata[20] = document.getElementById('a4').value;
        IDdata[21] = document.getElementById('a5').value;
        IDdata[22] = document.getElementById('pt').value;
        IDdata[23] = document.getElementById('currency').value;
        IDdata[24] = document.getElementById('er').value;
        IDdata[25] = document.getElementById('method').value;
        IDdata[26] = document.getElementById('r1').value;
        IDdata[27] = document.getElementById('r2').value;
        IDdata[28] = document.getElementById('r3').value;
       
        
        //IDdata[31] = vUsername;

        //IDdata[8] = document.getElementById('DDC').value;
        //IDdata[10] = document.getElementById('DOC').value;
        doc = document.getElementById('DOC').value;
        ddr = document.getElementById('DDC').value;

        //alert(IDdata[0]);
        //alert(IDdata[1]);
        //alert(IDdata[2]);
        //alert(IDdata[3]);
        //alert(IDdata[4]);
        //alert(IDdata[5]);
        //alert(IDdata[6]);
        //alert(IDdata[7]);
        //alert(IDdata[8]);
        //alert(IDdata[9]);
        //alert(IDdata[10]);
        //alert(IDdata[11]);
        //alert(IDdata[12]);
        //alert(IDdata[13]);
        //alert(IDdata[14]);
        //alert(IDdata[15]);
        //alert(IDdata[16]);
        //alert(IDdata[17]);
        //alert(IDdata[18]);
        //alert(IDdata[19]);
        //alert(IDdata[20]);
        //alert(IDdata[21]);
        //alert(IDdata[22]);
        //alert(IDdata[23]);
        //alert(IDdata[24]);
        //alert(IDdata[25]);
        //alert(IDdata[26]);
        //alert(IDdata[27]);
        //alert(IDdata[28]);
        //alert(IDdata[29]);
        //alert(IDdata[30]);
        //alert(IDdata[31]);



        event.preventDefault();

        IData = JSON.stringify(IDdata);
        //var rUrl = '@Url.Content("~/EB_DownTime.aspx/Saving_Data")';
        //alert("rUrl:" + rUrl);
        var xhttp1 = new XMLHttpRequest();

        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "EB_DownTime.aspx/VIPCase",
            data: "{'k':'" + IData + "'}",
            dataType: "json",
            success: function (data) {
                if (data.d == "1") {
                    if (confirm("This is a VIP client, Are you sure you want to proceed ?")) {
                        $.ajax({
                            type: "POST",
                            contentType: "application/json; charset=utf-8",
                            url: "EB_DownTime.aspx/Saving_Data",
                            data: "{'k':'" + IData + "' , 'doc':'" + doc + "', 'ddr':'" + ddr + "' , 'u': '" +vUsername+ "'  }",
                            dataType: "json",
                            success: function (data) {
                                if (data.d == 1) {
                                    alert("Record Saved Successfully");
                                    document.getElementById('edm').value = "";
                                    //document.getElementById('ct').value = "";
                                    document.getElementById('pn').value = "";
                                    document.getElementById('cn').value = "";
                                    document.getElementById('dn').value = "";
                                    document.getElementById('mn').value = "";
                                    document.getElementById('pna').value = "";
                                    document.getElementById('DateDOC').value = "";
                                    document.getElementById('DateDOR').value = "";
                                    document.getElementById('DDC').value = "";
                                    document.getElementById('DDCcode').value = "";
                                    document.getElementById('DOC').value = "";
                                    document.getElementById('DOCcode').value = "";
                                    document.getElementById('Con1').value = "";
                                    document.getElementById('Con2').value = "";
                                    document.getElementById('Con3').value = "";
                                    document.getElementById('Con4').value = "";
                                    document.getElementById('Con5').value = "";
                                    document.getElementById('a1').value = "";
                                    document.getElementById('a2').value = "";
                                    document.getElementById('a3').value = "";
                                    document.getElementById('a4').value = "";
                                    document.getElementById('a5').value = "";
                                    document.getElementById('pt').value = "";
                                    document.getElementById('currency').value = "";
                                    document.getElementById('er').value = "";
                                    document.getElementById('method').value = "";
                                    document.getElementById('r1').value = "";
                                    document.getElementById('r2').value = "";
                                    document.getElementById('r3').value = "";
                                    document.getElementById('r4').value = "";
                                }
                                else {
                                    alert("Record Not saved");
                                }

                                //alert("Success:" + data);
                            }

                        });
                    }
                }
                else {
                    //alert("0 value coming");
                    // ajaxcall2(IData);

                    $.ajax({
                        type: "POST",
                        contentType: "application/json; charset=utf-8",
                        url: "EB_DownTime.aspx/Saving_Data",
                        data: "{'k':'" + IData + "' , 'doc':'" + doc + "', 'ddr':'" + ddr + "' , 'u': '" + vUsername + "'  }",
                        dataType: "json",
                        success: function (data) {
                            if (data.d == 1) {
                                alert("Record Saved Successfully");
                                document.getElementById('edm').value = "";
                                //document.getElementById('ct').value = "";
                                document.getElementById('pn').value = "";
                                document.getElementById('cn').value = "";
                                document.getElementById('dn').value = "";
                                document.getElementById('mn').value = "";
                                document.getElementById('pna').value = "";
                                document.getElementById('DateDOC').value = "";
                                document.getElementById('DateDOR').value = "";
                                document.getElementById('DDC').value = "";
                                document.getElementById('DDCcode').value = "";
                                document.getElementById('DOC').value = "";
                                document.getElementById('DOCcode').value = "";
                                document.getElementById('Con1').value = "";
                                document.getElementById('Con2').value = "";
                                document.getElementById('Con3').value = "";
                                document.getElementById('Con4').value = "";
                                document.getElementById('Con5').value = "";
                                document.getElementById('a1').value = "";
                                document.getElementById('a2').value = "";
                                document.getElementById('a3').value = "";
                                document.getElementById('a4').value = "";
                                document.getElementById('a5').value = "";
                                document.getElementById('pt').value = "";
                                document.getElementById('currency').value = "";
                                document.getElementById('er').value = "";
                                document.getElementById('method').value = "";
                                document.getElementById('r1').value = "";
                                document.getElementById('r2').value = "";
                                document.getElementById('r3').value = "";
                                document.getElementById('r4').value = "";
                            }
                            else {
                                alert("Record Not saved");
                            }

                            //alert("Success:" + data);
                        }

                    });
                }
            }
        });



        //document.getElementById('edm').value = "";
        ////document.getElementById('ct').value = "";
        //document.getElementById('pn').value = "";
        //document.getElementById('cn').value = "";
        //document.getElementById('dn').value = "";
        //document.getElementById('mn').value = "";
        //document.getElementById('pna').value = "";
        //document.getElementById('DateDOC').value = "";
        //document.getElementById('DateDOR').value = "";
        //document.getElementById('DDC').value = "";
        //document.getElementById('DDCcode').value = "";
        //document.getElementById('DOC').value = "";
        //document.getElementById('DOCcode').value = "";
        //document.getElementById('Con1').value = "";
        //document.getElementById('Con2').value = "";
        //document.getElementById('Con3').value = "";
        //document.getElementById('Con4').value = "";
        //document.getElementById('Con5').value = "";
        //document.getElementById('a1').value = "";
        //document.getElementById('a2').value = "";
        //document.getElementById('a3').value = "";
        //document.getElementById('a4').value = "";
        //document.getElementById('a5').value = "";
        //document.getElementById('pt').value = "";
        //document.getElementById('currency').value = "";
        //document.getElementById('er').value = "";
        //document.getElementById('method').value = "";
        //document.getElementById('r1').value = "";
        //document.getElementById('r2').value = "";
        //document.getElementById('r3').value = "";
        //document.getElementById('r4').value = "";

    }

}

function CopyingSharedDrive() {
    if (confirm("Are You Sure You want to upload to shared Drive?")) {
        var IDdata = [];
        IDdata[0] = vUsername;
        IData = JSON.stringify(IDdata);

        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "EB_DownTime.aspx/CopyingToSharedDrive",
            data: "{'k':'" + IData + "'}",
            dataType: "json",
            success: function (data) {
                if (data.d == "1") {
                    alert("Upload Successful");
                }
                else {
                    alert("Upload Unsuccessful")
                }
            }
        });
    }

}
function fnSaveData() {
    var Sl_No = claim_no;
    var vProcessed_Date = full_date;
    var vClaim_Type = document.getElementById('ct').value;
    var vPolicy_Number = document.getElementById('pn').value;
    var vMember_Number = document.getElementById('cn').value;
    var vDependant_Number = document.getElementById('dn').value;
    var vMembership_Number = document.getElementById('mn').value;
    var vPatient_Name = document.getElementById('pna').value;
    var vDate_of_Consultation = document.getElementById('DateDOC').value;
    var vDate_of_Received = document.getElementById('DateDOR').value;
    var vDiagnosis_Description = document.getElementById('DDC').value;
    var vDiagnosis_Code = document.getElementById('DDCcode').value;
    var vDoctor_Name = document.getElementById('DOC').value;
    var vDoctor_Code = document.getElementById('DOCcode').value;
    var vConsultation_Type1 = document.getElementById('Con1').value;
    var vConsultation_Type2 = document.getElementById('Con2').value;
    var vConsultation_Type3 = document.getElementById('Con3').value;
    var vConsultation_Type4 = document.getElementById('Con4').value;
    var vConsultation_Type5 = document.getElementById('Con5').value;
    var vAmount_1 = document.getElementById('a1').value;
    var vAmount_2 = document.getElementById('a2').value;
    var vAmount_3 = document.getElementById('a3').value;
    var vAmount_4 = document.getElementById('a4').value;
    var vAmount_5 = document.getElementById('a5').value;
    var vPay_To = document.getElementById('pt').value;
    var vCurrency = document.getElementById('currency').value;
    var vExchange_Rate = document.getElementById('er').value;
    var vMethod = document.getElementById('method').value;
    var vRemark_1 = document.getElementById('r1').value;
    var vRemark_2 = document.getElementById('r2').value;
    var vRemark_3 = document.getElementById('r3').value;
    var vRemark_4 = document.getElementById('r4').value;

    //CHECKING FOR FILE EXISTANCE

    if (fso.FileExists(FilePath)) {
        alert("FileExists");
        var s = fso.OpenTextFile(FilePath, 1, false);

        if (!s.AtEndOfStream) {
            var str = s.readAll();
            var ss = str.split('\n');
            var l = ss.length;

            var v = parseInt(ss[l - 2][1]);
            var data = v + 1;
            s.Close();
            var fh = fso.OpenTextFile(FilePath, 8, false);
            fh.WriteLine('"' + data + '"' + "," + '"' + vUsername + '"' + "," + '"' + vProcessed_Date + '"' + "," + '"' + vClaim_Type + '"' + "," + '"' + vPolicy_Number + '"' + "," + '"' + vMember_Number + '"' + "," + '"' + vDependant_Number + '"' + "," + '"' + vMembership_Number + '"' + "," + '"' + vPatient_Name + '"' + "," + '"' + vDate_of_Consultation + '"' + "," + '"' + vDate_of_Received + '"' + "," + '"' + vDiagnosis_Description + '"' + "," + '"' + vDiagnosis_Code + '"' + "," + '"' + vDoctor_Name + '"' + "," + '"' + vDoctor_Code + '"' + "," + '"' + vConsultation_Type1 + '"' + "," + '"' + vAmount_1 + '"' + "," + '"' + vConsultation_Type2 + '"' + "," + '"' + vAmount_2 + '"' + "," + '"' + vConsultation_Type3 + '"' + "," + '"' + vAmount_3 + '"' + "," + '"' + vConsultation_Type4 + '"' + "," + '"' + vAmount_4 + '"' + "," + '"' + vConsultation_Type5 + '"' + "," + '"' + vAmount_5 + '"' + "," + '"' + vPay_To + '"' + "," + '"' + vCurrency + '"' + "," + '"' + vExchange_Rate + '"' + "," + '"' + vMethod + '"' + "," + '"' + vRemark_1 + '"' + "," + '"' + vRemark_2 + '"' + "," + '"' + vRemark_3 + '"' + "," + '"' + vRemark_4 + '"');
            fh.Close();
        }
    }
    else {
        alert("NO FileExists");
        var s = fso.CreateTextFile(FilePath, true);

        s.WriteLine('"Sl_No"' + "," + '"Username"' + "," + '"Processed Date"' + "," + '"Claim Type"' + "," + '"Policy Number"' + "," + '"Member Number"' + "," + '"Dependant Number"' + "," + '"Membership Number"' + "," + '"Patient Name"' + "," + '"Date of Consultation"' + "," + '"Date of Received"' + "," + '"Diagnosis Description"' + "," + '"Diagnosis Code"' + "," + '"Doctor Name"' + "," + '"Doctor Code"' + "," + '"Consultation Type 1"' + "," + '"Amount 1"' + "," + '"Consultation Type 2"' + "," + '"Amount 2"' + "," + '"Consultation Type 3"' + "," + '"Amount 3"' + "," + '"Consultation Type 4"' + "," + '"Amount 4"' + "," + '"Consultation Type 5"' + "," + '"Amount 5"' + "," + '"Pay To"' + "," + '"Currency"' + "," + '"Exchange Rate"' + "," + '"Method"' + "," + '"Remark 1"' + "," + '"Remark 2"' + "," + '"Remark 3"' + "," + '"Remark 4"');
        s.WriteLine('"' + Sl_No + '"' + "," + '"' + vUsername + '"' + "," + '"' + vProcessed_Date + '"' + "," + '"' + vClaim_Type + '"' + "," + '"' + vPolicy_Number + '"' + "," + '"' + vMember_Number + '"' + "," + '"' + vDependant_Number + '"' + "," + '"' + vMembership_Number + '"' + "," + '"' + vPatient_Name + '"' + "," + '"' + vDate_of_Consultation + '"' + "," + '"' + vDate_of_Received + '"' + "," + '"' + vDiagnosis_Description + '"' + "," + '"' + vDiagnosis_Code + '"' + "," + '"' + vDoctor_Name + '"' + "," + '"' + vDoctor_Code + '"' + "," + '"' + vConsultation_Type1 + '"' + "," + '"' + vAmount_1 + '"' + "," + '"' + vConsultation_Type2 + '"' + "," + '"' + vAmount_2 + '"' + "," + '"' + vConsultation_Type3 + '"' + "," + '"' + vAmount_3 + '"' + "," + '"' + vConsultation_Type4 + '"' + "," + '"' + vAmount_4 + '"' + "," + '"' + vConsultation_Type5 + '"' + "," + '"' + vAmount_5 + '"' + "," + '"' + vPay_To + '"' + "," + '"' + vCurrency + '"' + "," + '"' + vExchange_Rate + '"' + "," + '"' + vMethod + '"' + "," + '"' + vRemark_1 + '"' + "," + '"' + vRemark_2 + '"' + "," + '"' + vRemark_3 + '"' + "," + '"' + vRemark_4 + '"');

        s.Close();

    }

    //document.getElementById('edm').value = "";
    //document.getElementById('ct').value = "";
    //document.getElementById('pn').value = "";
    //document.getElementById('cn').value = "";
    //document.getElementById('dn').value = "";
    //document.getElementById('mn').value = "";
    //document.getElementById('pna').value = "";
    //document.getElementById('DateDOC').value = "";
    //document.getElementById('DateDOR').value = "";
    //document.getElementById('DDC').value = "";
    //document.getElementById('DDCcode').value = "";
    //document.getElementById('DOC').value = "";
    //document.getElementById('DOCcode').value = "";
    //document.getElementById('Con1').value = "";
    //document.getElementById('Con2').value = "";
    //document.getElementById('Con3').value = "";
    //document.getElementById('Con4').value = "";
    //document.getElementById('Con5').value = "";
    //document.getElementById('a1').value = "";
    //document.getElementById('a2').value = "";
    //document.getElementById('a3').value = "";
    //document.getElementById('a4').value = "";
    //document.getElementById('a5').value = "";
    //document.getElementById('pt').value = "";
    //document.getElementById('currency').value = "";
    //document.getElementById('er').value = "";
    //document.getElementById('method').value = "";
    //document.getElementById('r1').value = "";
    //document.getElementById('r2').value = "";
    //document.getElementById('r3').value = "";
    //document.getElementById('r4').value = "";

}




function visibletooltippn() {
    document.getElementById('sppn').style.visibility = 'visible';

}
function hidetooltippn() {
    document.getElementById('sppn').style.visibility = 'hidden';
}
//
function visibletooltipcn() {
    document.getElementById('spcn').style.visibility = 'visible';
}
function hidetooltipcn() {

    document.getElementById('spcn').style.visibility = 'hidden';
}
//
function visibletooltipmn() {

    document.getElementById('spmn').style.visibility = 'visible';
}
function hidetooltipmn() {

    document.getElementById('spmn').style.visibility = 'hidden';
}
//
function visibletooltipdn() {

    document.getElementById('spdn').style.visibility = 'visible';
}
function hidetooltipdn() {

    document.getElementById('spdn').style.visibility = 'hidden';
}
//
function visibletooltippcn() {

    document.getElementById('sppcn').style.visibility = 'visible';
}
function hidetooltippcn() {

    document.getElementById('sppcn').style.visibility = 'hidden';
}

function visibletooltipa11() {

    document.getElementById('spa1').style.visibility = 'visible';
}
function hidetooltipa1() {

    document.getElementById('spa1').style.visibility = 'hidden';
}

function visibletooltipa2() {

    document.getElementById('spa2').style.visibility = 'visible';
}
function hidetooltipa2() {

    document.getElementById('spa2').style.visibility = 'hidden';
}
//
function visibletooltipa3() {

    document.getElementById('spa3').style.visibility = 'visible';
}
function hidetooltipa3() {

    document.getElementById('spa3').style.visibility = 'hidden';
}
//
function visibletooltipa4() {

    document.getElementById('spa4').style.visibility = 'visible';
}
function hidetooltipa4() {

    document.getElementById('spa4').style.visibility = 'hidden';

}
//
function visibletooltipa5() {

    document.getElementById('spa5').style.visibility = 'visible';
}
function hidetooltipa5() {

    document.getElementById('spa5').style.visibility = 'hidden';

}
//
function visibletooltipddc() {

    document.getElementById('spddc').style.visibility = 'visible';
}
function hidetooltipddc() {

    document.getElementById('spddc').style.visibility = 'hidden';

}
function visibletooltipdoc() {

    document.getElementById('spdoc').style.visibility = 'visible';
}
function hidetooltipdoc() {

    document.getElementById('spdoc').style.visibility = 'hidden';

}
function visibletooltipdatec() {

    document.getElementById('spdatec').style.visibility = 'visible';
}
function hidetooltipdatec() {

    document.getElementById('spdatec').style.visibility = 'hidden';

}
function visibletooltipdater() {

    document.getElementById('spdater').style.visibility = 'visible';
}
function hidetooltipdater() {

    document.getElementById('spdater').style.visibility = 'hidden';
}

function visibletooltipedm() {

    document.getElementById('spedm').style.visibility = 'visible';
}
function hidetooltipedm() {

    document.getElementById('spedm').style.visibility = 'hidden';
}


function cleardata() {
    document.getElementById('edm').value = "";
    document.getElementById('ct').value = "";
    document.getElementById('pn').value = "";
    document.getElementById('cn').value = "";
    document.getElementById('dn').value = "";
    document.getElementById('mn').value = "";
    document.getElementById('pna').value = "";
    document.getElementById('DateDOC').value = "";
    document.getElementById('DateDOR').value = "";
    document.getElementById('DDC').value = "";
    document.getElementById('DDCcode').value = "";
    document.getElementById('DOC').value = "";
    document.getElementById('DOCcode').value = "";
    document.getElementById('Con1').value = "";
    document.getElementById('Con2').value = "";
    document.getElementById('Con3').value = "";
    document.getElementById('Con4').value = "";
    document.getElementById('Con5').value = "";
    document.getElementById('a1').value = "";
    document.getElementById('a2').value = "";
    document.getElementById('a3').value = "";
    document.getElementById('a4').value = "";
    document.getElementById('a5').value = "";
    document.getElementById('pt').value = "";
    document.getElementById('currency').value = "";
    document.getElementById('er').value = "";
    document.getElementById('method').value = "";
    document.getElementById('r1').value = "";
    document.getElementById('r2').value = "";
    document.getElementById('r3').value = "";
    document.getElementById('r4').value = "";
}

